BabySteps-Primeros pasos para Papis primerizos-Guía y Diario para Padres

1. Objetivo del Proyecto
El objetivo de esta aplicación es servir de apoyo a padres primerizos durante los primeros meses de crianza. La app combina una guía informativa con 18 hitos del desarrollo del bebé y un diario práctico para registrar tomas de alimentación, ciclos de sueño, cambios de pañal y medicación. El proyecto nace de una motivación personal basada en la experiencia real con mi hijo de 18 meses.

2. Prerrequisitos
Para ejecutar o visualizar el código de este proyecto se requiere:
* Un navegador web moderno (Chrome, Edge o Firefox) para su visualización en entornos como Zapp.run o DartPad.
* El SDK de Flutter (versión 3.0 o superior) si se desea ejecutar en un entorno local.
* Un editor de código como Visual Studio Code o Android Studio si se pretende realizar modificaciones técnicas.

3. Pasos para la instalación
Dado que el proyecto se entrega como un paquete de código fuente de Flutter, los pasos son:
1.  Descomprimir el archivo `.zip` proporcionado.
2.  Importar la carpeta en un entorno de desarrollo compatible con Flutter.
3.  Ejecutar el comando `flutter pub get` en la terminal para descargar las dependencias necesarias (como la librería `intl` para las fechas).
4.  Lanzar la aplicación en un emulador o dispositivo físico mediante el comando `flutter run`.

4. Observaciones y Agradecimientos
   -Observaciones: La aplicación utiliza una arquitectura de "Estado Sólido" mediante Widgets con estado (StatefulWidgets), asegurando que los registros del diario se muestren de forma inmediata tras ser introducidos. Se ha priorizado la experiencia de usuario (UX) mediante iconos de colores que identifican cada actividad.
   -Agradecimientos: Agradezco a mi familia, quienes han sido la fuente de inspiración para crear una herramienta que resuelva problemas cotidianos en la crianza, y a mi tutor Abelardo por las indicaciones, aunque no he podido asistir a ninguna en vivo, he visto cada clase mas de una vez, gracias Abelardo por todos sus consejos.

