import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() => runApp(GuiaPadresApp());

class GuiaPadresApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BabySteps App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: PantallaPrincipal(),
    );
  }
}

class Consejo {
  final String titulo;
  final String descripcion;
  final String etapa;
  Consejo(this.titulo, this.descripcion, this.etapa);
}

class Registro {
  final String tipo;
  final String hora;
  final String observacion;
  Registro(this.tipo, this.hora, this.observacion);
}

class PantallaPrincipal extends StatefulWidget {
  @override
  _PantallaPrincipalState createState() => _PantallaPrincipalState();
}

class _PantallaPrincipalState extends State<PantallaPrincipal> {
  // --- TUS CONSEJOS ---
  final List<Consejo> misConsejos = [
    Consejo("Contacto y Reflejos", "Fomentar el contacto piel a piel...", "0-1 Mes"),
    Consejo("Sueño y Rutinas", "Establecer una rutina consistente...", "1-2 Mes"),
    Consejo("Interacción Visual", "Interactuar hablando y sonriendo...", "2-3 Mes"),
    Consejo("Regresión del Sueño", "El bebé cambia sus ciclos de sueño...", "3-4 Mes"),
    Consejo("Desarrollo Motor", "Iniciar el tiempo boca abajo...", "4-5 Mes"),
    Consejo("Alimentación", "Introducir sólidos blandos poco a poco...", "5-6 Mes"),
    // Aquí puedes seguir pegando el resto de tus 18 consejos igual que estos
  ];

  final List<Registro> misRegistros = [];
  final TextEditingController _obsController = TextEditingController();
  String _tipoSeleccionado = 'Toma (Pecho/Bibe)';

  void _agregarRegistro() {
    setState(() {
      String horaActual = DateFormat('HH:mm').format(DateTime.now());
      misRegistros.insert(0, Registro(_tipoSeleccionado, horaActual, _obsController.text));
      _obsController.clear();
    });
    Navigator.pop(context);
  }

  void _mostrarFormulario(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 20, right: 20, top: 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(width: 50, height: 5, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10))),
                  const SizedBox(height: 20),
                  const Text("Nuevo Registro", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal)),
                  const SizedBox(height: 20),
                  DropdownButton<String>(
                    value: _tipoSeleccionado,
                    isExpanded: true,
                    items: <String>['Toma (Pecho/Bibe)', 'Sueño', 'Cambio de Pañal', 'Medicación/Vacunas']
                        .map((String v) => DropdownMenuItem<String>(value: v, child: Text(v))).toList(),
                    onChanged: (nuevo) {
                      setModalState(() => _tipoSeleccionado = nuevo!);
                    },
                  ),
                  TextField(controller: _obsController, decoration: const InputDecoration(labelText: "Observaciones")),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _agregarRegistro,
                    style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50), backgroundColor: Colors.teal, foregroundColor: Colors.white),
                    child: const Text("GUARDAR REGISTRO"),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("BabySteps: Guía y Diario"),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(icon: Icon(Icons.lightbulb), text: "Consejos"),
              Tab(icon: Icon(Icons.book), text: "Diario"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // --- PESTAÑA CONSEJOS (CON BANNER Y COLORES) ---
            Column(
              children: [
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.all(15),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [Colors.teal, Colors.teal.shade300]),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("¡Hola, Familia!", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                      SizedBox(height: 5),
                      Text("Explora los hitos de crecimiento de tu hijo.", style: TextStyle(color: Colors.white70, fontSize: 14)),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: misConsejos.length,
                    itemBuilder: (context, index) {
                      // Lógica de colores por etapa
                      Color colorEtapa = misConsejos[index].etapa.contains("0-2") 
                          ? Colors.orange.shade200 
                          : (misConsejos[index].etapa.contains("3-4") ? Colors.purple.shade100 : Colors.blue.shade100);

                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: colorEtapa,
                            child: const Icon(Icons.star, color: Colors.white),
                          ),
                          title: Text(misConsejos[index].titulo, style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text(misConsejos[index].etapa),
                          onTap: () => _mostrarDetalle(context, misConsejos[index]),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            // --- PESTAÑA DIARIO ---
            misRegistros.isEmpty
                ? const Center(child: Text("Pulsa + para anotar algo"))
                : ListView.builder(
                    itemCount: misRegistros.length,
                    itemBuilder: (context, index) {
                      IconData icono;
                      Color colorIcono;
                      if (misRegistros[index].tipo.contains('Toma')) {
                        icono = Icons.local_drink; colorIcono = Colors.orange;
                      } else if (misRegistros[index].tipo.contains('Sueño')) {
                        icono = Icons.bedtime; colorIcono = Colors.indigo;
                      } else if (misRegistros[index].tipo.contains('Pañal')) {
                        icono = Icons.baby_changing_station; colorIcono = Colors.brown;
                      } else {
                        icono = Icons.medical_services; colorIcono = Colors.red;
                      }
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: colorIcono.withOpacity(0.1),
                            child: Icon(icono, color: colorIcono),
                          ),
                          title: Text(misRegistros[index].tipo, style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text(misRegistros[index].observacion),
                          trailing: Text(misRegistros[index].hora),
                        ),
                      );
                    },
                  ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _mostrarFormulario(context),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  void _mostrarDetalle(BuildContext context, Consejo consejo) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Padding(
        padding: const EdgeInsets.all(25),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(consejo.titulo, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.teal)),
            const SizedBox(height: 10),
            Text(consejo.descripcion, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}